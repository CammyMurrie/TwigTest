1. run npm install to install node modules
2. run npm test to run tests
